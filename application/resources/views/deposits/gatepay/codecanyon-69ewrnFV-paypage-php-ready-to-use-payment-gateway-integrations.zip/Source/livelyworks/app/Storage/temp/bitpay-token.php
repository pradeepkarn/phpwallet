<?php

return [
    'token' => '7vG5ycrGcdc2F4zBQjqJAwXqLYZQ5tgoYHQ1grJAPb8H'
];
